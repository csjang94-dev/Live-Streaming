import json
import boto3
import os

medialive = boto3.client('medialive')
channel_id = os.environ['CHANNEL_ID']

def lambda_handler(event, context):
    """
    MediaLive 채널 시작/중지 제어
    """
    action = event.get('action', 'status')
    
    try:
        # 현재 상태 확인
        response = medialive.describe_channel(ChannelId=channel_id)
        current_state = response['State']
        
        print(f"Current channel state: {current_state}")
        
        if action == 'start':
            if current_state in ['IDLE', 'STOPPED']:
                medialive.start_channel(ChannelId=channel_id)
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': 'Channel start initiated',
                        'channelId': channel_id,
                        'previousState': current_state
                    })
                }
            else:
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': f'Channel already in {current_state} state',
                        'channelId': channel_id
                    })
                }
        
        elif action == 'stop':
            if current_state in ['RUNNING', 'STARTING']:
                medialive.stop_channel(ChannelId=channel_id)
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': 'Channel stop initiated',
                        'channelId': channel_id,
                        'previousState': current_state
                    })
                }
            else:
                return {
                    'statusCode': 200,
                    'body': json.dumps({
                        'message': f'Channel already in {current_state} state',
                        'channelId': channel_id
                    })
                }
        
        else:  # status
            return {
                'statusCode': 200,
                'body': json.dumps({
                    'channelId': channel_id,
                    'state': current_state,
                    'arn': response['Arn'],
                    'name': response['Name']
                })
            }
    
    except Exception as e:
        print(f"Error: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps({
                'error': str(e),
                'channelId': channel_id
            })
        }
